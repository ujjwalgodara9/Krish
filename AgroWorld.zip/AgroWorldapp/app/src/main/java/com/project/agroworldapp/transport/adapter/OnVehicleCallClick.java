package com.project.agroworldapp.transport.adapter;

import com.project.agroworldapp.transport.model.VehicleModel;

public interface OnVehicleCallClick {
    void callVehicleOwner(VehicleModel vehicleModel);
}
