package com.project.agroworldapp.articles.listener;

import com.project.agroworldapp.articles.model.CropsResponse;

public interface CropsClickListener {
    void onCropsClick(CropsResponse response);
}
