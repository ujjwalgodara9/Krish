package com.project.agroworldapp.articles.listener;

import com.project.agroworldapp.articles.model.FlowersResponse;

public interface FlowerClickListener {
    void onFlowersClick(FlowersResponse response);
}
