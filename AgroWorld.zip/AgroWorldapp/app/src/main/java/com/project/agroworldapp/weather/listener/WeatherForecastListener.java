package com.project.agroworldapp.weather.listener;

public interface WeatherForecastListener {

    void onForecastWeatherCardClick(String description);
}
