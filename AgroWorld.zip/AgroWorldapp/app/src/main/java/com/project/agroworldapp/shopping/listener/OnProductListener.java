package com.project.agroworldapp.shopping.listener;

import com.project.agroworldapp.shopping.model.ProductModel;

public interface OnProductListener {
    void onProductClick(ProductModel productModel);
}
