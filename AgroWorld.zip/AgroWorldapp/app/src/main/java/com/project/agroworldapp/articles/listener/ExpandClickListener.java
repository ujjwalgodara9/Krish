package com.project.agroworldapp.articles.listener;

import com.project.agroworldapp.articles.model.HowToExpandResponse;

public interface ExpandClickListener {
    void onExpandItemClick(HowToExpandResponse response);
}
