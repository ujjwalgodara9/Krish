package com.project.agroworldapp.articles.listener;

import com.project.agroworldapp.articles.model.InsectControlResponse;

public interface InsectControlListener {
    void onInsectControlItemClick(InsectControlResponse response);
}
