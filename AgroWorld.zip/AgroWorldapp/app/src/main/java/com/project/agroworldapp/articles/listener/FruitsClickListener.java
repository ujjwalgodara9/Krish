package com.project.agroworldapp.articles.listener;

import com.project.agroworldapp.articles.model.FruitsResponse;

public interface FruitsClickListener {
    void onFruitClick(FruitsResponse response);
}
