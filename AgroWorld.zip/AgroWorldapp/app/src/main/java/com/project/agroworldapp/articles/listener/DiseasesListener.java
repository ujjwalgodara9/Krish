package com.project.agroworldapp.articles.listener;

import com.project.agroworldapp.articles.model.DiseasesResponse;

public interface DiseasesListener {
    void onDiseaseItemClick(DiseasesResponse response);
}
